def fun111(base, exp):
    ans = 1
    i = 1
    while i <= exp:
        ans = ans * base
        i = i + 1

    return ans