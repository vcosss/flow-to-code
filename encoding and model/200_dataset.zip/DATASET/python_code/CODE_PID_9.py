def fun9(side):
    area = side * side
    return area