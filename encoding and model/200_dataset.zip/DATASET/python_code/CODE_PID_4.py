def fun4(p, q):
    s = (p - q) + (p + q) + (q + 1) * (p + 1)
    return s