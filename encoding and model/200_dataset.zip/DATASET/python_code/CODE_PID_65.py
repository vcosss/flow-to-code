def fun65(ch):
    if ch == 'a' or ch == 'e' or ch == 'i' or ch == 'o' or ch == 'u':
        return 'Vowel'
    else:
        return 'Consonant'