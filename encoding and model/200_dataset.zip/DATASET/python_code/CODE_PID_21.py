def fun21(x, y):
    z = x + y
    return z