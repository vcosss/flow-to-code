def fun6(celcius):
    fahrenheit = 9 / 5 * celcius + 32
    return fahrenheit