def fun76(N):
    sum = 0
    for i in range(0, N+1, 2):
        sum = sum + i
    return sum