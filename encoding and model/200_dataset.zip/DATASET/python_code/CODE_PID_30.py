def fun30(ms):
    kmhr = ms * 18 / 5
    return kmhr