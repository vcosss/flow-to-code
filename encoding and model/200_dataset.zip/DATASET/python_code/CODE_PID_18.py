def fun18(length, breadth, height):
    volume = length * breadth * height
    return volume