def fun63(ch):
    ascii = ord(ch)
    if ascii >= 65 and ascii <= 90:
        return 'Upper case'
    else:
        return 'Lower case'