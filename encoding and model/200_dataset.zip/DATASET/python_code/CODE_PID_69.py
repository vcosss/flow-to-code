def fun69(string1, string2):
    if string1 == string2:
        return 'Both are equal'
    else:
        return 'Both are not equal'