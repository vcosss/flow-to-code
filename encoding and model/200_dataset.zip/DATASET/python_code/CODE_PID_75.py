def fun75(N):
    pro = 1
    i = 1
    while i <= N:
        pro = pro * i
        i = i + 1
    return pro 