def fun37(string):
    ch = string[0]
    return ch