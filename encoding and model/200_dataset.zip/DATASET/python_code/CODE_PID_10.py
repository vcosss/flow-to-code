def fun10(radius):
    area = 3.14 * radius * radius
    return area