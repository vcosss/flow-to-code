def fun125(N):
    term = 1
    for i in range(1, N):
        term = term * 10 + 1
    
    return term
