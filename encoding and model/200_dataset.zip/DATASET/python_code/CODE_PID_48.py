def fun48(num):
    if num % 5 == 0 and num % 11 == 0:
        return 'Divisible'
    else:
        return 'Not Divisible'