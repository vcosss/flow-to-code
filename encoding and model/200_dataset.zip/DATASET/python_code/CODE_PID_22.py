def fun22(x, y):
    z = x - y
    return z