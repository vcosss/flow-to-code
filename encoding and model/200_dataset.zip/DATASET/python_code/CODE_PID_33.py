def fun33(mass, velocity):
    ke = 0.5 * mass * velocity * velocity
    return ke