def fun35(degree):
    radian = degree * 0.0174533
    return radian