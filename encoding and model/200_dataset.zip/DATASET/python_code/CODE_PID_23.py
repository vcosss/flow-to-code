def fun23(x, y):
    z = x * y
    return z