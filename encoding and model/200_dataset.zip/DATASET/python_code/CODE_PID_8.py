def fun8(kelvin):
    celcius = kelvin - 273.15
    return celcius