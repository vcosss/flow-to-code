def fun182(a, d, N):
    term = a + (N - 1) * d
    return term