def fun74(N):
    pro = 1
    for i in range(1, N+1):
        pro = pro * i
    return pro