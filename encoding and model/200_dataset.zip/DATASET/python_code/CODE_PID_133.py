def fun133(N):
    sum = 0
    for i in range(1, N+1):
        sum = sum + i * i

    return sum