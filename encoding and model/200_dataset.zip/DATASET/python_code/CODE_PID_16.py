def fun16(radius, height):
    volume = 3.142 * radius * radius * height
    return volume