def fun49(num, k):
    if num % k == 0:
        return 'It is a factor'
    else:
        return 'It is not a factor'