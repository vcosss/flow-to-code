def fun39(string, index):
    ch = string[index]
    return ch