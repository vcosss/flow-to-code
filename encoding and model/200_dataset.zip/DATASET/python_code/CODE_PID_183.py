def fun183(a, r, N):
    term = a * r ** (N - 1)
    return term