def fun91(a, b):
    sum = 0

    for i in range(a, b+1):
        sum = sum + i
    
    return sum