def fun58(num1, num2):
    if num1 == num2:
        return 'Both are equal'
    else:
        return 'Both are not equal'