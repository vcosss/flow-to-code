def fun1(x):
    y = 16 + x - 20
    return y