def fun110(base, exp):
    ans = 1
    for i in range(exp+1):
        ans = ans * base

    return ans