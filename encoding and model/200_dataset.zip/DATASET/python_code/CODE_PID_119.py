def fun119(a, d, N):
    term = a
    for i in range(1, N):
        term = term + d
    return term
