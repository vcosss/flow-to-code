def fun113(N, M):
    ans = 0
    i = 1
    while i <= N:
        ans = ans + M
        i = i + 1

    return ans