def fun7(celcius):
    kelvin = celcius + 273.15
    return kelvin