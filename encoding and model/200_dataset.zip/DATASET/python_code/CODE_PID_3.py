def fun3(x):
    z = x//2 + x % 2
    return z