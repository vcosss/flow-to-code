def fun27(hours):
    seconds = hours * 3600
    return seconds