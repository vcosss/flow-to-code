def fun31(mass, volume):
    density = mass / volume
    return density