def fun34(radian):
    degree = radian * 57.2958
    return degree