def fun81(N):
    sum = 0
    i = 1
    while i <= N:
        sum = sum + i
        i = i + 2
    return sum