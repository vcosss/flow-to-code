def fun184(a, d, N):
    apterm = a + (N - 1) * d
    term = 1 / apterm
    return term