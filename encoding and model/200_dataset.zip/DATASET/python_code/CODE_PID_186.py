def fun186(a, r, N):
    sum = a (r ** N - 1) / (r - 1)
    return sum