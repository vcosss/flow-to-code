def fun11(length, breadth):
    area = length * breadth
    return area