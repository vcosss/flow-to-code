def fun2(a, b):
    c = a + b * 100
    return c