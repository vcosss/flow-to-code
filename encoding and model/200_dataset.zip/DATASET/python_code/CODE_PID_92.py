def fun92(a, b):
    sum = 0
    i = a
    while i <= b:
        sum = sum + i
        i = i + 1

    return sum