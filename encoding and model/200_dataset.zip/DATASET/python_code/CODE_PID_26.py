def fun26(cm):
    m = cm / 100
    return m