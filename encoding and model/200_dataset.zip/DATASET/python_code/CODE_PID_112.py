def fun112(N, M):
    ans = 0
    for i in range(N):
        ans = ans + M

    return ans