def fun47(num):
    if num % 2 == 0:
        return 'Odd Number'
    else:
        return 'Even Number'