def fun25(m):
    cm = m * 100
    return cm