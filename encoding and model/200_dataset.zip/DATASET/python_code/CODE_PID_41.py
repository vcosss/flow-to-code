def fun41(x, y):
    if x > y:
        mx = x
    else:
        mx = y
    return mx