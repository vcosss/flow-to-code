def fun32(distance, time):
    velocity = distance / time
    return velocity