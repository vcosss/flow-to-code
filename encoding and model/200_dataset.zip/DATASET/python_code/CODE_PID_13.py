def fun13(radius):
    perimeter = 2 * 3.142 * radius
    return perimeter