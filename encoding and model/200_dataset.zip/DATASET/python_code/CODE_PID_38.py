def fun38(string):
    ch = string[-1]
    return ch