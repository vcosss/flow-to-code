def fun187(P, R, T):
    SI = P * R * T / 100
    return SI