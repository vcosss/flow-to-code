def fun80(N):
    sum = 0
    for i in range(1, N+1, 2):
        sum = sum + i
    return sum