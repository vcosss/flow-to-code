def fun15(radius):
    volume = (4 * 3.142 * radius * radius * radius) / 3
    return volume 