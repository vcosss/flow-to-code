def fun72(N):
    sum = 0
    for i in range(1, N+1):
        sum = sum + i
    return sum