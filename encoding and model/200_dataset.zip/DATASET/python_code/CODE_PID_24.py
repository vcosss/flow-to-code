def fun24(x, y):
    z = x / y
    return z