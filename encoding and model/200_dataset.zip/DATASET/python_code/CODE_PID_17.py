def fun17(side):
    volume = side * side * side
    return volume