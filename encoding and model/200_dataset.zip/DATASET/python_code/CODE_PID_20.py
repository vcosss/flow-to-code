def fun20(radius, height):
    sarea = 2 * 3.142 * radius * radius + 2 * 3.142 * radius * height
    return sarea