def fun5(fahrenheit):
    celcius = 5 / 9 * (fahrenheit - 32)
    return celcius