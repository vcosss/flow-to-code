def fun36(timeperiod):
    frequency = 1 / timeperiod
    return frequency