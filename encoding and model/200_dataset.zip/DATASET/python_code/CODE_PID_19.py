def fun19(radius, length):
    sarea = 3.142 * radius * length + 3.142 * radius * radius
    return sarea