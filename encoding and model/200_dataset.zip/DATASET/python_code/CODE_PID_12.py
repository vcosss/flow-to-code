def fun12(side):
    perimeter = 6 * side
    return perimeter