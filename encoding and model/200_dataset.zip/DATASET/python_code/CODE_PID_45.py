def fun45(x):
    if x < 0:
        return 'Less than zero'
    else:
        return 'Greater than or equal to zero'