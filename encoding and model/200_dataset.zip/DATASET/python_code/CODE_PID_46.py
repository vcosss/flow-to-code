def fun46(num):
    if num > 0:
        return 'Positive Number'
    else:
        return 'Negative Number'