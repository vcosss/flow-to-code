def fun43(x, y):
    if x < y:
        mn = x
    else:
        mn = y
    return mn