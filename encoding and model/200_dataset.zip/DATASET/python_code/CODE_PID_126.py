def fun126(N):
    term = 1
    i = 1 
    while i < N:
        term = term * 10 + 1
        i = i + 1
    
    return term