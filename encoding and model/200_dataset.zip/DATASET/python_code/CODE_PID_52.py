def fun52(angle1, angle2, angle3):
    if angle1 + angle2 + angle3 == 180:
        return 'Forms Valid Triangle'
    else:
        return 'Cannot form a Valid Triangle'