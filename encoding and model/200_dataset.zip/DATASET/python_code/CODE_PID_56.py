def fun56(CP, SP):
    if CP > SP:
        return CP - SP
    else:
        return SP - CP