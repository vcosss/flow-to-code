def fun77(N):
    sum = 0
    i = 0
    while i <= N:
        sum = sum + i
        i = i + 2
    return sum