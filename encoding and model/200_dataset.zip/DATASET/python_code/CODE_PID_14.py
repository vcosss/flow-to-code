def fun14(length, breadth):
    perimeter = 2 * (length + breadth)
    return perimeter