def fun40(age):
    if age >= 18:
        return 'Can vote'
    else:
        return 'Cannot vote'