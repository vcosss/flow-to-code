def fun29(kmhr):
    ms = kmhr * 5 / 18
    return ms