def fun185(a, d, N):
    sum = N * (2 * a + (N - 1) * d) / 2
    return sum    