def fun28(seconds):
    hours = seconds / 3600
    return hours